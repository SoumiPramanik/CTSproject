package chapter5;
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class TruTimeAvg {
 
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://onecognizant.cognizant.com/Home");
		//navigate to trutime
		driver.findElement(By.id("oneC_searchAutoComplete")).sendKeys("Trutime");
		driver.findElement(By.xpath("//*[text()='TruTime ']")).click();

		//Currentmonth
		driver.switchTo().frame("appFrame");
		String month=driver.findElement(By.xpath("//*[@class=\"ui-datepicker-month\"]")).getText();
		System.out.println("Current Month is : "+month);
		String Year=driver.findElement(By.xpath("//*[@class=\"ui-datepicker-year\"]")).getText();
		System.out.println("Current year is : "+Year);
		//month avg timings
		String month_avg=driver.findElement(By.id("A2")).getText();
		System.out.println("Month avg is : "+month_avg);
		String month_swipeavg=driver.findElement(By.xpath("//*[@class=\"swipeAvg MonAvg ng-binding\"]")).getText();
		System.out.println("Month Swipe avg is : "+month_swipeavg);
		String month_topup=driver.findElement(By.xpath("//*[@class=\"topUpAvg MonAvg ng-binding\"]")).getText();
		System.out.println("Month topup avg is : "+month_topup);
		//Year avg timings
		String year_avg=driver.findElement(By.id("A3")).getText();
		System.out.println("Year avg is : "+year_avg);
		String year_swipeavg=driver.findElement(By.xpath("(//*[@class=\"swipeAvg MonAvg ng-binding\"])[2]")).getText();
		System.out.println("Year Swipe avg is : "+year_swipeavg);
		String year_topup=driver.findElement(By.xpath("(//*[@class=\"topUpAvg MonAvg ng-binding\"])[2]")).getText();
		System.out.println("Year topup avg is : "+year_topup);
		//Close the Browser
		driver.close();

 
	}
 
}