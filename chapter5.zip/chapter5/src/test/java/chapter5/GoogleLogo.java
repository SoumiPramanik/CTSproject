package chapter5;

import java.util.List;
 
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleLogo{
 
	public static void main(String[] args) throws InterruptedException {

		// TODO Auto-generated method stub

		WebDriver driver= new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://www.google.com");

		WebElement logo=driver.findElement(By.xpath("//*[@class='lnXdpd']"));

		if(logo.isDisplayed()) {

			System.out.println("Logo Displayed");

		}

		String title=driver.getTitle();

		System.out.println("Title is:"+title);

		driver.findElement(By.xpath("//*[@title=\"Search\"]")).sendKeys("Cognizant");

		Thread.sleep(3000);

		List<WebElement> searchresults=driver.findElements(By.className("wM6W7d"));

	

		int count=0;

		for(WebElement result:searchresults) {

			System.out.println(result.getText());

			count++;

		}

		System.out.println("Total Results :"+count);


		driver.close();

 
	}
 
}

 